cd ..
R CMD BUILD bootclust
R CMD INSTALL bootclust_*.tar.gz
mv bootclust_*.tar.gz bootclust/
