library('testthat')
library('bootclust')

test_package('bootclust')
