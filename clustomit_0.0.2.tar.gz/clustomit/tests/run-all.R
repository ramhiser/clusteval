library('testthat')
library('clustomit')

test_package('clustomit')
